#pragma once
#include <SFML/Graphics.hpp>

namespace utils
{
void centerizeTextOrigin(sf::Text &text);
}
